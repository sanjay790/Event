/* eslint-disable no-unused-vars */
import React from 'react';

const Error = () => {
    return (
        <div>
            <h1 className='text-4xl font-bold h-[70vh] flex items-center justify-center'>Oops!!! data not found</h1>
        </div>
    );
};

export default Error;