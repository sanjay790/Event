## 5 Project features.
1. I am creating wedding event website, with responsive to desktop, tablet and mobile. So that the user can use it very easily from any device.

2. We added beautiful animation to create better user experience.

3. User can toggle between login and register page.

4. If user want to visit event details then use will be redirect to login page.If user already not logged.

5. This website has a navbar so that user can easily go to his wanted page.

Website Name: Wedding Event Planner.

Live link : https://ninth-assignment-12921.web.app/
